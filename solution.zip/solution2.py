# ==============================================
# Lab Assignment 4 - String Manipulation (Q10–Q11)
# ==============================================

# Q10: Palindrome Rearrangement Checker
def palindrome_checker(s):
    # TODO:
    # - Return "Yes" if string can be rearranged into a palindrome
    # - Return "No" otherwise
    # - Return "input invalid" for empty or non-string
    lst = []
    if type(s) == str and len(s) >= 1:
        for i in s.lower():
            if i == " ":
                None
            else:
                if len(lst) <=2:
                    if s.count(i) % 2 == 1:
                        lst.append(i)
                else:
                    break
        if len(lst) <= 1:
            return "Yes"
        else:
            return "No"
    else:
        return "input invalid"


# Q11: String Rotation Validator
def rotation_checker(s1, s2):
    # TODO:
    # - Return True if s2 is a rotation of s1
    # - Return False otherwise
    # - Return "input invalid" if inputs are not strings or lengths differ
    if type(s1) is str and type(s2) is str and len(s1) == len(s2):
        t = 0
        x = s1[0]
        y = s2.index(x)
        for i in s1:
            j = s2.index(i)
            z = j - s1.index(i) % len(s1)
            if z == y:
                t +=1
        if t == len(s1):
            return True
        else:
            return False  
    else:
         return "input invalid"

# ==============================================
# Lab Assignment 4 - String Manipulation (Q10–Q11)
# ==============================================

# Q10: Palindrome Rearrangement Checker
def palindrome_checker(s):
    # TODO:
    # - Return "Yes" if string can be rearranged into a palindrome
    # - Return "No" otherwise
    # - Return "input invalid" for empty or non-string
    lst = []
    if type(s) == str and len(s) >= 1:
        s1 = s.lower()
        for i in s1:
            s2 = s1.replace(" ","")
            if len(lst) <=2:
                if s2.count(i) % 2 == 1:
                    lst.append(i)
            else:
                    break
        if len(lst) <= 1:
            return "Yes"
        else:
            return "No"
    else:
        return "input invalid"



# Q11: String Rotation Validator
def rotation_checker(s1, s2):
    # TODO:
    # - Return True if s2 is a rotation of s1
    # - Return False otherwise
    # - Return "input invalid" if inputs are not strings or lengths differ
    if type(s1) is str and type(s2) is str and len(s1) == len(s2):
        all_words = []
        x = len(s1)
        for i in range(0,len(s1)):
            t = ""
            for j in range(0,x):
                k = (i + j) % x
                t += s1[k]
            all_words.append(t)
        return s2 in all_words    ###
    else:
         return "input invalid"

print(rotation_checker("waterbottle", "erbottlewat"))
#!/bin/bash

# ==============================================
# Lab Assignment 4 - Bash Section (Q1–Q6)
# ==============================================
# Instructions:
# - Fill in the code for each question in the TODO section.
# - DO NOT remove the "Qx:" markers (they are used for grading).
# - You may add helper commands, but outputs must match the expected format.
# ==============================================

# Q1
echo "Q1:"
# Extract unique words from essay.txt (case-insensitive), sort, and print in lowercase
tr '[:upper:]' '[:lower:]' < essay.txt | tr -c '[:alnum:]' '\n' | sort -u
echo ""


# Q2
echo "Q2:"
# Count regular files, directories, and symbolic links in current directory (non-recursive)
files=$(find . -maxdepth 1 -type f | wc -l)
dirs=$(find . -maxdepth 1 -type d | wc -l)
symlinks=$(find . -maxdepth 1 -type l | wc -l)
echo "Files: $files"
echo "Directories: $dirs"
echo "Symlinks: $symlinks"
echo ""


# Q3
echo "Q3:"
# Print top 5 largest files in 'bigfiles' directory (filename - size), sorted descending
find bigfiles -type f -printf "%s %p\n" | sort -nr | head -5 | awk '{print $2 " - " $1}'
echo ""


# Q4
echo "Q4:"
# Print essay.txt with line numbers (1-based, in format: "1: line content")
i=1
for line in $(cat essay.txt); do
    echo "$i:$line"
    i = $((i+1))
    done
echo ""


# Q5
echo "Q5:"
# Print current user's info
echo "User: $USER"
echo "Home: $HOME"
echo "Shell: $SHELL"
echo ""


# Q6
echo "Q6:"
# Find all files modified in last 24 hours in current directory (non-recursive)
find . -maxdepth 1 -type f -mtime -1